import SkeletonAccountPage from "@modules/skeletons/templates/skeleton-account-page"

export default function Loading() {
  return <SkeletonAccountPage />
}
